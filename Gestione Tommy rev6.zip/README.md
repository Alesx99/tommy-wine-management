# 🍷 Gestione Tommy - Bar e Cantina

**Form HTML semplice per l'inserimento e gestione dei dati del bar e cantina di Tommy**

## 📋 Caratteristiche

### ✅ **Funzionalità Principali:**
- **👥 Gestione Clienti** - Inserimento dati completi con esportazione Excel
- **📄 Gestione Fatture** - Monitoraggio pagamenti e scadenze
- **🍺 Gestione Prodotti** - Inventario alcolici con controllo scorte
- **🍷 Gestione Vini** - Catalogo cantina con valutazioni
- **📊 Esportazione Excel** - Portabilità completa dei dati
- **📥 Importazione Excel** - Carica dati da file Excel esistenti
- **💾 Salvataggio Automatico** - Dati salvati nel browser

### 🎯 **Vantaggi:**
- ✅ **Nessuna installazione** - Funziona direttamente nel browser
- ✅ **Nessun server** - File HTML standalone
- ✅ **Portabilità totale** - Importa/Esporta Excel per uso ovunque
- ✅ **Salvataggio automatico** - Dati persi mai più
- ✅ **Interfaccia moderna** - Design responsive e intuitivo
- ✅ **Dati sicuri** - Tutto salvato localmente nel browser

## 🚀 Come Utilizzare

### **1. Apri il file**
- Doppio click su `index.html`
- Si apre automaticamente nel browser

### **2. Inserisci i dati**
- Naviga tra le tab (Clienti, Fatture, Prodotti, Vini)
- Compila i form con i dati
- Clicca "Aggiungi" per salvare
- **I dati si salvano automaticamente!**

### **3. Importa da Excel**
- Clicca "Importa Excel" nella sezione desiderata
- Seleziona il file Excel (.xlsx o .xls)
- I dati vengono importati automaticamente
- Duplicati vengono evitati automaticamente

### **4. Esporta in Excel**
- Clicca "Esporta Excel" nella sezione desiderata
- Il file Excel si scarica automaticamente
- Apri con Excel, LibreOffice o Google Sheets

## 📁 Struttura File

```
Gestione Tommy/
├── index.html          # Form principale
└── README.md          # Questo file
```

## 🎨 Sezioni Disponibili

### **👥 Clienti**
- Nome, cognome, email, telefono
- Indirizzo completo
- Data registrazione
- Note personalizzate

### **📄 Fatture**
- Numero fattura
- Cliente associato
- Date emissione e scadenza
- Importo e stato pagamento
- Note aggiuntive

### **🍺 Prodotti**
- **Categoria Principale**: Distillati, Liquori, Vini, Birre, Altro
- **Sottocategoria**: Rum, Gin, Vodka, Whisky, Tequila, Cognac, Brandy, Bourbon, Scotch, Irish, Amari, Digestivi, Creme, Premium, Flavored, Rossi, Bianchi, Spumanti, Dessert, Fortificati, Lager, Ale, Speciali, Italiane
- Marca e fornitore
- Prezzi acquisto e vendita
- Quantità e scorte minime
- Codice prodotto

### **🍷 Vini**
- Nome, produttore, annata
- Tipologia (Rosso, Bianco, Rosato, Spumante, Dessert, Fortificato, Passito, Moscato, Prosecco, Champagne, Lambrusco, Vermouth)
- Regione di provenienza
- Prezzi e quantità
- Sistema valutazione stelle
- Descrizione dettagliata

## 📊 Import/Export Excel

### **Esportazione:**
Ogni sezione permette di esportare i dati in formato Excel:

1. **Clienti_Tommy.xlsx** - Lista completa clienti
2. **Fatture_Tommy.xlsx** - Tutte le fatture con stati
3. **Prodotti_Tommy.xlsx** - Inventario prodotti alcolici
4. **Vini_Tommy.xlsx** - Catalogo cantina completo

### **Importazione:**
- Carica file Excel esistenti
- Riconosce automaticamente le colonne
- Evita duplicati intelligentemente
- Converte automaticamente i formati

## 💾 Salvataggio Automatico

- **Dati salvati nel browser** - Non si perdono mai
- **Caricamento automatico** - All'apertura del file
- **Sincronizzazione** - Tra inserimento e visualizzazione
- **Backup sicuro** - Nel localStorage del browser

## 🎯 Caratteristiche Tecniche

- **HTML5** - Standard moderno
- **CSS3** - Design responsive e animazioni
- **JavaScript** - Logica interattiva
- **XLSX.js** - Import/Export Excel nativo
- **Local Storage** - Salvataggio dati nel browser

## 📱 Compatibilità

- ✅ **Chrome** - Pienamente supportato
- ✅ **Firefox** - Pienamente supportato
- ✅ **Safari** - Pienamente supportato
- ✅ **Edge** - Pienamente supportato
- ✅ **Mobile** - Design responsive

## 🔧 Personalizzazione

Il file `index.html` può essere facilmente modificato per:
- Aggiungere nuovi campi
- Cambiare colori e stile
- Modificare layout
- Aggiungere nuove sezioni

## 💡 Suggerimenti d'Uso

1. **Backup regolari** - Esporta i dati Excel periodicamente
2. **Importazione** - Usa Excel per inserire grandi quantità di dati
3. **Organizzazione** - Usa le note per informazioni aggiuntive
4. **Controllo scorte** - Monitora le quantità minime
5. **Fatture** - Tieni traccia delle scadenze
6. **Portabilità** - Usa l'export Excel per trasferire dati tra PC

## 🔄 Workflow Consigliato

1. **Primo utilizzo**: Inserisci i dati manualmente o importa da Excel
2. **Uso quotidiano**: Aggiungi nuovi dati tramite i form
3. **Backup**: Esporta periodicamente in Excel
4. **Trasferimento**: Usa i file Excel per spostare dati tra PC
5. **Ripristino**: Importa i file Excel quando necessario

## 🆘 Supporto

Per problemi o modifiche:
1. Apri il file `index.html` con un editor di testo
2. Modifica il codice HTML/CSS/JavaScript
3. Salva e ricarica nel browser

---

**Sviluppato per Tommy - Bar e Cantina**  
*Versione 2.0 - Febbraio 2024* 